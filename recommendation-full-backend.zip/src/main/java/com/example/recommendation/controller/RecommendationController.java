package com.example.recommendation.controller;

import com.example.recommendation.model.TestResult;
import com.example.recommendation.service.RecommendationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/recommendations")
@CrossOrigin
public class RecommendationController {
    private final RecommendationService recommendationService;

    public RecommendationController(RecommendationService recommendationService) {
        this.recommendationService = recommendationService;
    }

    @GetMapping("/{userId}")
    public List<TestResult> getRecommendations(@PathVariable Long userId) {
        return recommendationService.recommendChapters(userId);
    }
}
