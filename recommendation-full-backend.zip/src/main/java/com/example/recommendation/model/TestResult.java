package com.example.recommendation.model;

import jakarta.persistence.*;

@Entity
public class TestResult {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int score;

    @ManyToOne
    private User user;

    @ManyToOne
    private Chapter chapter;
}
