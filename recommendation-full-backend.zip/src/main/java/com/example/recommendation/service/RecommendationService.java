package com.example.recommendation.service;

import com.example.recommendation.model.TestResult;
import com.example.recommendation.repository.TestResultRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RecommendationService {
    private final TestResultRepository testResultRepository;

    public RecommendationService(TestResultRepository testResultRepository) {
        this.testResultRepository = testResultRepository;
    }

    public List<TestResult> recommendChapters(Long userId) {
        return testResultRepository.findByUserId(userId)
                .stream()
                .filter(result -> result.getScore() < 50)
                .collect(Collectors.toList());
    }
}
